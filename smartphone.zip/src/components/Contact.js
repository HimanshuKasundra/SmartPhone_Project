export default function Contact()
{
    return <h1>Contact here</h1>
}